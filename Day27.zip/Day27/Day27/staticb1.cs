﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day27
{
    static class Mydata
    {
        public static int id;
        public static string name;
        static Mydata()
        {
            id = 111;
            name = "Reliance";
        }
        public static void getchangeddata(int x, string n)
        {
            id = x;
            name = n;
        }

        public static void callme()
        {
            Console.WriteLine(" hey i am in My data ");
        }
    }
    class staticb1
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Business group name = " + Mydata.name + " is having id = " + Mydata.id);
            Mydata.callme();
            Mydata.getchangeddata(333,"BIGBAZAR");
            Console.WriteLine("Business group name = " + Mydata.name + " is having id = " + Mydata.id);           
        }
    }
}
