﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day27
{
    class Boxing_unboxing
    {
        static void Main(string[] args)
        {
            int i = 10;
            object ob = i;//boxing
            Console.WriteLine(i);
            Console.WriteLine(ob);

            int j = (int)ob;//unboxing
            Console.WriteLine(j);
        }
    }
}
