﻿using System;
using System.IO;

namespace Day27
{
    class Binarywrite1
    {
        static void Main(string[] args)
        {
            using (BinaryWriter writer = new BinaryWriter(File.Open("E:\\Mybin.dat", FileMode.Create)))
            {
                writer.Write(111);
                writer.Write("Praveen");
                writer.Write(81.5);
                writer.Write('A');
                writer.Write(true);
            }
            readme();
        }
        public static void readme()
        {
            using (BinaryReader reader = new BinaryReader(File.Open("E:\\Mybin.dat", FileMode.Open)))
            {
                Console.WriteLine("ROLL NO       "+ reader.ReadInt32());
                Console.WriteLine("NAME          " + reader.ReadString());
                Console.WriteLine("PERCENTAGE    " + reader.ReadDouble());
                Console.WriteLine("GRADE         " + reader.ReadChar());
                Console.WriteLine("PASSED        " + reader.ReadBoolean());
            }
        }
    }
}
