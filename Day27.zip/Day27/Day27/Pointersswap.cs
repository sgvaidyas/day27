﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day27
{
    class Pointersswap
    {
        public static unsafe void swap(int* p,int* q )
        {
            int temp;
            temp = *p;
            *p = *q;
            *q = temp;
        }
        static unsafe void Main(string[] args)
        {
            int a = 10;
            int b = 20;
            Console.WriteLine("A = {0} and B = {1}",a,b);
            swap(&a , &b);
            Console.WriteLine("A = {0} and B = {1}", a, b);
        }
    }
}
