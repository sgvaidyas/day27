﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day27
{
    class Employee
    {
        public string name;
        public int id;
        public double sal;
        internal Employee(string name,int id,float sal)
        {
            this.name = name;
            this.id = id;
            this.sal = sal;
        }
        public static void Main(string[] args)
        {
            Employee ob1 = new Employee("rrrr", 888, 909);
            Console.WriteLine("NAME"+ob1.name);
        }
    }
}
