﻿#define MYTEST
#define mycar
using System;


namespace Day27
{
    class dire1
    {
        static void Main(string[] args)
        {

        #if (DEBUG && !MYTEST)
                    Console.WriteLine("DEBUG is defined");
        #elif (!DEBUG && MYTEST)
                Console.WriteLine("MYTEST is defined");
        #elif (DEBUG && MYTEST && mycar)
                Console.WriteLine("DEBUG and MYTEST mycar are defined");  
        #else
                Console.WriteLine("DEBUG and MYTEST are not defined");
        #endif
        }
    }
}
