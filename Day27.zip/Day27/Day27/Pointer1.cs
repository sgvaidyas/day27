﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day27
{
    class Pointersample
    {
        public void Myfun()
        {
            unsafe
            {
                int x = 10;
                int* ptr = &x;
                Console.WriteLine(x);
                Console.WriteLine((int)ptr);
                Console.WriteLine(*ptr);
            }            
        }
    }        
    class Pointer1
    {
        static void Main(string[] args)
        {
            Pointersample ob = new Pointersample();
            ob.Myfun();
        }
    }
}
