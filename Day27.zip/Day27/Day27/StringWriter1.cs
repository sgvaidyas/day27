﻿using System;
using System.IO;
using System.Text;

namespace Day27
{
    class StringWriter1
    {
        static void Main(string[] args)
        {
            string text = "";
            string n;
            do
            {
                Console.WriteLine("Enter the string and q to exit");
                n = Console.ReadLine();
                if (n != "q")
                    text += n + "\n";
            } while (n != "q");
            StringBuilder s = new StringBuilder();

            StringWriter writer = new StringWriter(s);

            writer.WriteLine(text);

            writer.Close();
            StringReader reader = new StringReader(s.ToString());
            while(reader.Peek() >-1)
            {
                Console.WriteLine(reader.ReadLine());
            }
        }
    }
}
