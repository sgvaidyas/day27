﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day27
{
    struct Artist
    {
        public int id, fees;
        public string name;

        public void getdata()
        {
            Console.WriteLine("Enter id fees & name");
            id = int.Parse(Console.ReadLine());
            fees = int.Parse(Console.ReadLine());
            name = Console.ReadLine();
        }
        public void display()
        {
            Console.WriteLine("  " + id + "  |  " + name + "  | " + fees);
        }

    }
    class Struct1
    {
        static void Main(string[] args)
        {
            Artist ob = new Artist();
            ob.getdata();
            ob.display();
        }
    }
}
