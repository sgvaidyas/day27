﻿using System;
using System.IO;

namespace Day27
{
    class Binarywithclass
    {
        public Employee emp;
        public Binarywithclass()
        {
            Console.WriteLine("ID name and sal");
            int id = int.Parse(Console.ReadLine());
            string name = Console.ReadLine();
            float sal = float.Parse(Console.ReadLine());
            emp = new Employee(name,id,sal);
            
        }
        public void write()
        {
            using (BinaryWriter writer = new BinaryWriter(File.Open("E:\\MyEmp.dat", FileMode.Create)))
            {
                writer.Write(emp.name);
                writer.Write(emp.id);
                writer.Write(emp.sal);                
            }
        }
        public void read()
        {
            using (BinaryReader reader = new BinaryReader(File.Open("E:\\MyEmp.dat", FileMode.Open)))
            {
                Console.WriteLine("NAME  = " + reader.ReadString() );
                Console.WriteLine("ID    = " + reader.ReadInt32());
                Console.WriteLine("SAL   = " + reader.ReadDouble());

            }
        }

        static void Main(string[] args)
        {
            Binarywithclass ob = new Binarywithclass();
            ob.write();
            ob.read();
        }
    }
}
