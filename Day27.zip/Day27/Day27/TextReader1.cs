﻿using System;
using System.IO;

namespace Day27
{
    class TextReader1
    {
        static void Main(string[] args)
        {
            using (TextReader ob = File.OpenText("E:\\Nameslist.txt"))
            {
                Console.WriteLine(ob.ReadToEnd());
            }
        }
    }
}
