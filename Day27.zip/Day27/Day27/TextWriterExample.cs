﻿using System;
using System.IO;

namespace Day27
{
    class TextWriterExample
    {
        static void Main(string[] args)
        {
            using (TextWriter writer = File.CreateText("E:\\NamesList.txt"))
            {
                writer.WriteLine("Abhitosh");
                writer.WriteLine("MAdhuri");
                writer.WriteLine("Srivani");
                writer.WriteLine("Akash");
                writer.WriteLine("Althaf");
            }
        }
    }
}
